
package com.mycompany.competencia;
import GUI.Espectador;
import GUI.opciones_espectador;
import GUI.ranking_gral;
import GUI.registro_espectador;
import java.util.*; 

public class Competencia {

    public static void main(String[] args) {
        
        Espectador espectador = new Espectador();
        espectador.setVisible(true);
        espectador.setLocationRelativeTo(null);
        
    }
}
