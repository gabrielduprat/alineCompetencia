package Logic;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author hecto
 */
public class Espect_Code {
    public static void main(String[] args){
        
    }
    
}

class Espectador{
    private String nombre_espectador;
    
    public Espectador(){
     
}
    
    //Seleccionar una CATEGORIA
   //mostrar RANKING_GRAL por categoría
    //mostrar RANKING_ETAPAS
    //mostrar LISTA_PARTICIP
    //
}
