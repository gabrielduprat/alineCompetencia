/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logic;

import javax.swing.JFrame;
import javax.swing.JList;

/**
 *
 * @author hecto
 */
public class lista {
    
    JFrame frame = new JFrame("ranking_gral");
    JList <Participante> lista = new JList<>();
    
}
